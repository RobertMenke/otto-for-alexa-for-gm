"use strict";

module.exports = {
    test : function() {
        return "Hello world"
    }
};