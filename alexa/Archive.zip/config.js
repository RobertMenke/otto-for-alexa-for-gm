
module.exports = {
    ARN   : "arn:aws:lambda:us-east-1:282766053803:function:ChevyHitters",
    APP_ID: "amzn1.ask.skill.fed31ed9-7ced-4903-a507-c3b6c5e1e569"
};