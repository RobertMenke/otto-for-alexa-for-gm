"use strict";

module.exports = {
    "en-US": {
        "translation": {
            "SKILL_NAME"      : "ChevyHitters",
            "GET_FACT_MESSAGE": "Ok, ",
            "HELP_MESSAGE"    : "Some message indicating what the app can do",
            "HELP_REPROMPT"   : "What can I help you with?",
            "STOP_MESSAGE"    : "Safe travels!"
        }
    }
};