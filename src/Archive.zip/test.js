const express = require("express");
const alexa   = require("alexa-app");

//Instantiate express and alexa app
const app       = express();
const alexa_app = new alexa.app("ChevyHitters");


alexa_app.intent("test", {
    "slots" : {
        "number" : "AMAZON.NUMBER"
    },
    "utterance": [
        "say the number {-|number}"
    ]
}, function(request, response){
    const number = request.slot("number");
    response.say("You asked for the number " + number);
});

// setup the alexa app and attach it to express before anything else
alexa_app.express({ expressApp: app, router: express.Router() });