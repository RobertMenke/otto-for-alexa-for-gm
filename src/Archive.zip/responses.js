module.exports = {
    test : function() {
        return "Hello world"
    }
};